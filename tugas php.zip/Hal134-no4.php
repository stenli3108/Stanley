<?php
    $a = 5;
    echo ++$a;
    echo $a;
    echo "<br>";

    $b = 5;
    echo $b++;
    echo $b;
    echo "<br>";

    $a = 5;
    echo --$a;
    echo $a;
    echo "<br>";

    $b = 5;
    echo $b--;
    echo $b;

    ?>