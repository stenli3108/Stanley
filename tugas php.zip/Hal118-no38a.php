<?php
    $koordinat =[
                  [
                    ["A"],["B"]
                  ],
                  [
                    ["C"],["D"]
                  ],
                ];

    echo $koordinat[0][0][0];
    echo "<br>";
    echo $koordinat[0][1][0];
    echo "<br>";
    echo $koordinat[1][0][0];
    echo "<br>";
    echo $koordinat[1][1][0];

    ?>