<?php
    $siswa = [
               "satu"  => "Andri",
                "dua"  => "Joko",
                "tiga"  => "Sukma",
                "empat"  => "Rina"
                ];

    echo $siswa["dua"];
    echo "<br>";
    echo $siswa["empat"];
    ?>