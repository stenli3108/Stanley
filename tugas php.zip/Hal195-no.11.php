<?php
function tambah($satu,$dua){
    $hasil =$satu + $dua;
    echo $hasil;
}

tambah(6,10);
echo"<br>";
tambah(100,99);
?>