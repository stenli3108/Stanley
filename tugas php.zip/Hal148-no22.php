<?php
$a = 10;
$a += 5;
echo $a; 
echo "<br>";

$a = 55;
$a /= 5;
echo $a; 
echo "<br>";

$a = "Belajar";
$a .= "PHP";
echo $a; 
?>