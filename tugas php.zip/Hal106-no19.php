<?php
  $situs = "www.duniailkom.com";

  $belajar1 = 'Sedang belajar programming di $situs';
  echo $belajar1;
  //Sedang belajar programming di $situs

  echo "<br>";

  $belajar2 = "Sedang belajar programming di $situs";
  echo $belajar2;
  //Sedang belajar programming di www.duniailkom.com
?>