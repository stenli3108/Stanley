<?php
    $macam2 = array(121,"Joko",44.99,"Belajar PHP");
    $macam2[4] = "Duniailkom";
    $macam2[5] = 212;
    $macam2[6] = 3.14;

    echo"<pre>";
    var_dump($macam2);
    echo "</pre>";

?>