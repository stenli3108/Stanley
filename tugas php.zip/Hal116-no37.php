<?php
    $koordinat = array(
                        array(8,2),
                        array(2,4),
                        array(1,7)
                        );
    echo $koordinat[0][0];
    echo "<br>";
    echo $koordinat[0][1];
    echo "<br>";
    echo $koordinat[2][1];
    echo "<br>";

    ?>