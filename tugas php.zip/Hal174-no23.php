<?php
for ($i = 9; $i > 0; $i--) {
    echo "Anak ayam turun $i<br>";
}
?>