<?php
function salam() {
    echo "<p>Selamat Pagi</p>";
}
salam(); 
salam();
salam();

?>