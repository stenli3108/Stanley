<?php
function tambah($satu,$dua) {
    $hasil = $satu +$dua;
    return $hasil;
echo "kalimat ini tidak akan pernah dijalankan...";
}
echo tambah(5,7);
?>