<?php
    var_dump(12 < 14); echo "<br/>"; // bool(true)
    var_dump(14 < 14); echo "<br/>"; // bool(false)
    var_dump(14 <= 14); echo "<br/>"; // bool(true)
    var_dump(10 <> 14); echo "<br/>"; // bool(true)
    var_dump(15 == 10); echo "<br/>"; // bool(false)
    var_dump(10 == 10); echo "<br/>"; // bool(true)
    var_dump(150 == 1502);                // bool(true)

    ?>